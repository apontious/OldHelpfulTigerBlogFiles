//
//  BindingsArrayController.h
//  Bindings Categorizer
//
//  Created by Andrew Pontious on 8/10/05.
//

#import <Cocoa/Cocoa.h>


@interface BindingsArrayController : NSArrayController {

}

@end

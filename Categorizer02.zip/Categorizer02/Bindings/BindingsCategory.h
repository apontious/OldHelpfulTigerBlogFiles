//
//  BindingsCategory.h
//  Bindings Categorizer
//
//  Created by Andrew Pontious on 8/6/05.
//

#import <Cocoa/Cocoa.h>


@interface BindingsCategory : NSObject 
{
@private

	NSString *name;
	NSString *specialSortKey;
}

	/*!
	 @method initAsAllCategory:
	 Special initializer for "All" category that stays at top of categories list and an't be renamed.
	 */
- (id)initAsAllCategory;

- (NSString *)name;
- (void)setName:(NSString *)newName;

	/*!
	 @method editable
	 NO for "All" category, YES for others.
	 */
- (BOOL)editable;

@end

//
//  BindingsDelegate.h
//  Bindings Categorizer
//
//  Created by Andrew Pontious on 8/6/05.
//

#import <Cocoa/Cocoa.h>


@interface BindingsDelegate : NSObject 
{
	/*! @var categories Contains Category instances. */
	NSMutableArray *categories;

	IBOutlet NSArrayController *categoriesController;
	
	IBOutlet NSTableView *categoryTable;
	IBOutlet NSTableColumn *categoryTableColumn;
}

- (IBAction)newCategory:(id)sender;

// Methods for Category name validation.
+ (BindingsDelegate *)sharedDelegate;
- (NSArray *)categories;

@end

//
//  DataSourceCategory.h
//  DataSource Categorizer
//
//  Created by Andrew Pontious on 8/6/05.
//

#import <Cocoa/Cocoa.h>


@interface DataSourceCategory : NSObject 
{
@private

	NSString *name;
}

- (NSString *)name;
- (void)setName:(NSString *)newName;

@end

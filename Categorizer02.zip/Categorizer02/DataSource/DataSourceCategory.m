//
//  DataSourceCategory.m
//  DataSource Categorizer
//
//  Created by Andrew Pontious on 8/6/05.
//

#import "DataSourceCategory.h"

#import "DataSourceDelegate.h"

@implementation DataSourceCategory

- (void)dealloc
{
	[name release];
	
	[super dealloc];
}

- (NSString *)name
{
	return name;
}
- (void)setName:(NSString *)newName
{
	[newName retain];
	[name release];
	
	name = newName;
}

- (NSString *)description
{
	return [NSString stringWithFormat:@"%@ %p \"%@\"", NSStringFromClass([self class]), self, [self name]];
}

@end

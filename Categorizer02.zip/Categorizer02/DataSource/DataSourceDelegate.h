//
//  DataSourceDelegate.h
//  DataSource Categorizer
//
//  Created by Andrew Pontious on 8/6/05.
//

#import <Cocoa/Cocoa.h>

@class DataSourceTableView;

@interface DataSourceDelegate : NSObject 
{
	/*! @var categories Contains Category instances. */
	NSMutableArray *categories;

	IBOutlet DataSourceTableView *categoryTable;
	IBOutlet NSTableColumn *categoryTableColumn;
}

// Actions

- (IBAction)newCategory:(id)sender;

@end

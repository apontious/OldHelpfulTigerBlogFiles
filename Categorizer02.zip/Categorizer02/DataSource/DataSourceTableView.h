//
//  DataSourceTableView.h
//  DataSource Categorizer
//
//  Created by Andrew Pontious on 8/10/05.
//

#import <Cocoa/Cocoa.h>


@interface DataSourceTableView : NSTableView {

}

@end

@interface NSObject (DataSourceTableViewDelegate)

- (BOOL)tableView:(DataSourceTableView *)tableView shouldHandleString:(NSString *)string forTableColumn:(NSTableColumn *)tableColumn row:(int)row;

@end
